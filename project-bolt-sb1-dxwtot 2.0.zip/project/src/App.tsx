import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/layout/Layout';
import { Dashboard } from './pages/Dashboard';
import { Login } from './pages/Login';
import { Appointments } from './pages/Appointments';
import { MedicalRecords } from './pages/MedicalRecords';
import { HealthMetrics } from './pages/HealthMetrics';
import { VideoConsultation } from './pages/VideoConsultation';
import { Patients } from './pages/Patients';
import { useAuthStore } from './store/authStore';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

function App() {
  const { isAuthenticated } = useAuthStore();

  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/login" element={
            isAuthenticated ? <Navigate to="/dashboard" replace /> : <Login />
          } />
          <Route path="/dashboard" element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          } />
          <Route path="/appointments" element={
            <PrivateRoute>
              <Appointments />
            </PrivateRoute>
          } />
          <Route path="/records" element={
            <PrivateRoute>
              <MedicalRecords />
            </PrivateRoute>
          } />
          <Route path="/metrics" element={
            <PrivateRoute>
              <HealthMetrics />
            </PrivateRoute>
          } />
          <Route path="/consultations" element={
            <PrivateRoute>
              <VideoConsultation />
            </PrivateRoute>
          } />
          <Route path="/patients" element={
            <PrivateRoute>
              <Patients />
            </PrivateRoute>
          } />
          <Route path="/" element={
            isAuthenticated ? <Navigate to="/dashboard" replace /> : <Navigate to="/login" replace />
          } />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;