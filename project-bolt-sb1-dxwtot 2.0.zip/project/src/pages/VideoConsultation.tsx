import React from 'react';
import { Video, Mic, MicOff, VideoOff, Phone } from 'lucide-react';

export function VideoConsultation() {
  const [isMuted, setIsMuted] = React.useState(false);
  const [isVideoOn, setIsVideoOn] = React.useState(true);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Video Consultation</h1>
        <div className="flex items-center space-x-2">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
            <span className="w-2 h-2 mr-2 rounded-full bg-green-400"></span>
            Connected
          </span>
        </div>
      </div>

      <div className="bg-gray-900 rounded-lg aspect-video relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-white text-center">
            <Video className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <p className="text-gray-400">Camera preview would appear here</p>
          </div>
        </div>

        <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex items-center space-x-4">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`p-4 rounded-full ${
              isMuted ? 'bg-red-500' : 'bg-gray-700'
            } hover:bg-opacity-80 transition-colors`}
          >
            {isMuted ? (
              <MicOff className="h-6 w-6 text-white" />
            ) : (
              <Mic className="h-6 w-6 text-white" />
            )}
          </button>

          <button
            onClick={() => setIsVideoOn(!isVideoOn)}
            className={`p-4 rounded-full ${
              !isVideoOn ? 'bg-red-500' : 'bg-gray-700'
            } hover:bg-opacity-80 transition-colors`}
          >
            {isVideoOn ? (
              <Video className="h-6 w-6 text-white" />
            ) : (
              <VideoOff className="h-6 w-6 text-white" />
            )}
          </button>

          <button className="p-4 rounded-full bg-red-500 hover:bg-red-600 transition-colors">
            <Phone className="h-6 w-6 text-white" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="font-medium text-gray-900">Connection Status</h3>
          <p className="mt-1 text-sm text-gray-500">Strong (45ms)</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="font-medium text-gray-900">Duration</h3>
          <p className="mt-1 text-sm text-gray-500">00:00:00</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="font-medium text-gray-900">Quality</h3>
          <p className="mt-1 text-sm text-gray-500">HD (720p)</p>
        </div>
      </div>
    </div>
  );
}