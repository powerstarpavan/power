import { create } from 'zustand';
import type { MedicalRecord } from '../types';

interface RecordsState {
  records: MedicalRecord[];
  addRecord: (record: MedicalRecord) => void;
  updateRecord: (id: string, record: Partial<MedicalRecord>) => void;
  deleteRecord: (id: string) => void;
  getPatientRecords: (patientId: string) => MedicalRecord[];
}

export const useRecordsStore = create<RecordsState>((set, get) => ({
  records: [],
  addRecord: (record) =>
    set((state) => ({ records: [...state.records, record] })),
  updateRecord: (id, updatedRecord) =>
    set((state) => ({
      records: state.records.map((record) =>
        record.id === id ? { ...record, ...updatedRecord } : record
      ),
    })),
  deleteRecord: (id) =>
    set((state) => ({
      records: state.records.filter((record) => record.id !== id),
    })),
  getPatientRecords: (patientId) =>
    get().records.filter((record) => record.patientId === patientId),
}));