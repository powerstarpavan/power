import { create } from 'zustand';
import type { Appointment } from '../types';

interface AppointmentState {
  appointments: Appointment[];
  addAppointment: (appointment: Appointment) => void;
  updateAppointment: (id: string, appointment: Partial<Appointment>) => void;
  cancelAppointment: (id: string) => void;
  getDoctorAppointments: (doctorId: string) => Appointment[];
  getPatientAppointments: (patientId: string) => Appointment[];
}

export const useAppointmentStore = create<AppointmentState>((set, get) => ({
  appointments: [],
  addAppointment: (appointment) =>
    set((state) => ({ appointments: [...state.appointments, appointment] })),
  updateAppointment: (id, updatedAppointment) =>
    set((state) => ({
      appointments: state.appointments.map((appointment) =>
        appointment.id === id
          ? { ...appointment, ...updatedAppointment }
          : appointment
      ),
    })),
  cancelAppointment: (id) =>
    set((state) => ({
      appointments: state.appointments.map((appointment) =>
        appointment.id === id
          ? { ...appointment, status: 'cancelled' }
          : appointment
      ),
    })),
  getDoctorAppointments: (doctorId) =>
    get().appointments.filter((appointment) => appointment.doctorId === doctorId),
  getPatientAppointments: (patientId) =>
    get().appointments.filter((appointment) => appointment.patientId === patientId),
}));