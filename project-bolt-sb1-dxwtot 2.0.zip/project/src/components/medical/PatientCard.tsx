import React from 'react';
import { User, Calendar, FileText } from 'lucide-react';

interface PatientCardProps {
  name: string;
  age: number;
  lastVisit: Date;
  nextAppointment?: Date;
  condition?: string;
  onClick?: () => void;
}

export function PatientCard({
  name,
  age,
  lastVisit,
  nextAppointment,
  condition,
  onClick,
}: PatientCardProps) {
  return (
    <div
      onClick={onClick}
      className="bg-white rounded-lg shadow p-6 cursor-pointer hover:shadow-md transition-shadow"
    >
      <div className="flex items-start space-x-4">
        <div className="bg-blue-100 rounded-full p-3">
          <User className="h-6 w-6 text-blue-600" />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-medium text-gray-900">{name}</h3>
          <p className="text-sm text-gray-500">Age: {age}</p>
          {condition && (
            <p className="text-sm text-gray-500 mt-1">
              Condition: {condition}
            </p>
          )}
          <div className="mt-4 space-y-2">
            <div className="flex items-center text-sm text-gray-500">
              <FileText className="h-4 w-4 mr-2" />
              Last Visit: {lastVisit.toLocaleDateString()}
            </div>
            {nextAppointment && (
              <div className="flex items-center text-sm text-gray-500">
                <Calendar className="h-4 w-4 mr-2" />
                Next Appointment: {nextAppointment.toLocaleDateString()}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}