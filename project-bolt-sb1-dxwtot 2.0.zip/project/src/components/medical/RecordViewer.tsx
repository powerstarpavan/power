import React from 'react';
import { FileText, Download, Calendar, User } from 'lucide-react';
import { Button } from '../shared/Button';
import { formatDate } from '../../lib/utils';

interface RecordViewerProps {
  record: {
    id: string;
    date: Date;
    title: string;
    doctor: string;
    diagnosis: string;
    prescription?: string;
    attachments?: string[];
    notes?: string;
  };
  onClose: () => void;
}

export function RecordViewer({ record, onClose }: RecordViewerProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex justify-between items-start mb-6">
        <h2 className="text-xl font-semibold text-gray-900">{record.title}</h2>
        <Button variant="secondary" size="sm" onClick={onClose}>
          Close
        </Button>
      </div>

      <div className="space-y-4">
        <div className="flex items-center text-sm text-gray-500">
          <Calendar className="h-4 w-4 mr-2" />
          {formatDate(record.date)}
          <User className="h-4 w-4 ml-4 mr-2" />
          {record.doctor}
        </div>

        <div className="border-t pt-4">
          <h3 className="font-medium text-gray-900 mb-2">Diagnosis</h3>
          <p className="text-gray-700">{record.diagnosis}</p>
        </div>

        {record.prescription && (
          <div className="border-t pt-4">
            <h3 className="font-medium text-gray-900 mb-2">Prescription</h3>
            <p className="text-gray-700">{record.prescription}</p>
          </div>
        )}

        {record.notes && (
          <div className="border-t pt-4">
            <h3 className="font-medium text-gray-900 mb-2">Additional Notes</h3>
            <p className="text-gray-700">{record.notes}</p>
          </div>
        )}

        {record.attachments && record.attachments.length > 0 && (
          <div className="border-t pt-4">
            <h3 className="font-medium text-gray-900 mb-2">Attachments</h3>
            <div className="space-y-2">
              {record.attachments.map((attachment, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-2 bg-gray-50 rounded"
                >
                  <div className="flex items-center">
                    <FileText className="h-4 w-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-600">
                      {attachment.split('/').pop()}
                    </span>
                  </div>
                  <Button variant="secondary" size="sm">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}