import React from 'react';
import { Folder, FileText, Plus } from 'lucide-react';
import { Button } from '../shared/Button';

interface PatientFolderProps {
  patientId: string;
  name: string;
  recordCount: number;
  lastUpdated: Date;
  onAddRecord?: () => void;
  onViewRecords?: () => void;
}

export function PatientFolder({
  name,
  recordCount,
  lastUpdated,
  onAddRecord,
  onViewRecords,
}: PatientFolderProps) {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <div className="flex items-start justify-between">
        <div className="flex items-center">
          <Folder className="h-8 w-8 text-blue-500" />
          <div className="ml-3">
            <h3 className="text-lg font-medium text-gray-900">{name}</h3>
            <p className="text-sm text-gray-500">
              {recordCount} records · Last updated {lastUpdated.toLocaleDateString()}
            </p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button variant="secondary" size="sm" onClick={onViewRecords}>
            <FileText className="h-4 w-4 mr-2" />
            View
          </Button>
          <Button size="sm" onClick={onAddRecord}>
            <Plus className="h-4 w-4 mr-2" />
            Add Record
          </Button>
        </div>
      </div>
    </div>
  );
}